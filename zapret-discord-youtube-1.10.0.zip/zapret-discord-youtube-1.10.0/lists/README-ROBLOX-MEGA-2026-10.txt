Roblox MEGA expansion (2026-10)

Main files:
- list-roblox-mega-2026-10.txt: consolidated real/documented/observed Roblox hostnames from existing pack + public API/CDN observations.
- list-roblox-real-mega-2026-10.txt: clean union without broad third-party parent domains.
- list-roblox-speed-core-2026-10.txt: low-noise latency/download focused set.
- list-roblox-external-cdn-2026-10.txt: observed ancillary CDN/challenge/delivery hosts.
- list-roblox-ultra-candidates-2026-10.txt: generated candidates, not all verified; keep separate.
- ipset-roblox-current-2026-10.txt: current public Roblox CIDRs found in public technical sources.

Note: more domains do not inherently lower ping. For Roblox game traffic, UDP port ranges and the resolved game-server IP are more important than adding arbitrary hostnames. A huge unverified hostlist can also increase matching overhead.
