# ULTRA LIST PACK — 2026-09-30

This revision expands War Thunder/Gaijin and Roblox/Roblox Studio coverage substantially.

War Thunder focus:
- warthunder.com service families: mgate / match / char / wtm-host / host / chat / voice / config / launcher
- gaijin.net CDN families (Akamai, Gcore, CacheFly, CloudFront-related surfaces)
- exact current-observed IPs are kept separately in ipset-warthunder-max.txt
- official game/launcher ports remain in ports-warthunder*.txt

Roblox Studio focus:
- Creator Hub / Studio / publish / develop / cloud / OAuth / auth
- gamejoin / matchmaking / realtime / presence / asset delivery
- rbxcdn edge families (c/t/images/fts/apis)
- CAPTCHA / Arkose / STUN/TURN endpoints

Important: Hostlists only help traffic that exposes a matching hostname. War Thunder battle traffic can use direct IP connections and DNS-based regional routing, so exact IPs + required ports can matter more than adding another hundred hostnames.

Current evidence checked 2026-09-30:
- Netify identifies War Thunder as using multiple cloud/CDN networks and shows current hostnames such as mgate-wtm-02, char-lw-nl-005-2/3/5 and CDN families.
- Netify currently lists 91.225.125.13 as Gaijin network sample, and current host pages expose additional AWS/servers.com/OVH/Yandex/Gcore addresses.
- Roblox Creator Hub docs currently document auth.roblox.com and apis.roblox.com / OAuth APIs, and current Netify data exposes apis.rbxcdn.com, clientsettingscdn.roblox.com, authorize.roblox.com and many other Roblox hosts.

Some generated hostname families are deliberately separated into *-candidates.txt: they are broad-test candidates, not claims that every generated name currently resolves.
