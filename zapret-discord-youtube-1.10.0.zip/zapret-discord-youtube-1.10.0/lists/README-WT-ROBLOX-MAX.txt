MAX update for War Thunder and Roblox Studio

War Thunder:
- Added a much larger observed hostname/service set covering launcher, auth, mgate, match, char, chat, voice, replay, configs, telemetry and CDN names.
- Added exact current/observed IPs and historical community game-server IPs to ipset-warthunder-max.txt and merged them into ipset-all-expanded.txt.
- Kept official ports in ports-warthunder-all.txt. Gaijin officially documents TCP 80,443,5222,8443,7850-7854,7800-7802 and UDP 20000-30000,3478-3480,16172; launcher TCP 27022-27042,6881,8090; dev TCP 20443,33333.

Roblox Studio:
- Added a large Creator/Studio endpoint set, including official support endpoints, Creator publishing/development services, realtime/matchmaking, update/CDN hosts, Arkose/FunCaptcha, STUN/TURN and known infrastructure names.
- Roblox officially documents the core HTTP/HTTPS endpoints and UDP 49152-65535 after an experience launches. Roblox also notes that Play/experience launch uses assetgame.roblox.com and proxying is not supported there.

Important:
Zapret hostlists automatically match subdomains of a listed domain; wildcards are not needed and may not be supported. Because War Thunder battle traffic uses UDP and can go directly to game-server IPs, domain additions alone may not fix a 'no connection to server' error; the exact-IP list and the required UDP range matter.
