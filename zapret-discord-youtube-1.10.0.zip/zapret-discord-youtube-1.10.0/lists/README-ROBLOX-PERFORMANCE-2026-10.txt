

2026-10 expansion:
- Added more client/Studio/Creator API and service hosts.
- Added public observed regional edge/terminal host families (edge/term/titanium and edge-term variants).
- Expanded rbxcdn c0-c15 and t0-t15 as candidates; documented/observed core c0-c7/t0-t7 remain included.
- Added CDN/delivery provider domains used in public Roblox connectivity lists.
- Added a separate backend-candidates list so speculative/generated infrastructure names are not mixed into the main list.

Caution: larger hostlists do not inherently lower game latency. Roblox uses DNS/geo-based delivery and dynamic game-server IPs, so RTT is mostly determined by routing to the selected game server. The lists are intended to avoid false blocking when using host-based DPI bypass.
