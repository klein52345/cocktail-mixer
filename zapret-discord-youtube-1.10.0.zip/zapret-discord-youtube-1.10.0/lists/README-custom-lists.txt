Custom domain/IP lists for zapret-style matching

Updated 2026-09-30.

Dedicated files:
- list-roblox.txt / list-roblox-expanded.txt — Roblox web/API/CDN/auth/launch/dependency domains
- list-games.txt / list-games-expanded.txt — game/platform list with expanded War Thunder + Gaijin services
- list-general-custom.txt / list-general-custom-expanded.txt — merged general list
- ipset-all.txt / ipset-all-expanded.txt — Roblox CIDR additions used by community troubleshooting
- ports-roblox.txt — Roblox dynamic UDP range
- ports-warthunder.txt — official War Thunder game + launcher ports

Coverage is intentionally broad. This can increase collateral traffic matched by a desync profile, especially for shared CDN providers.

Sources checked on 2026-09-30:
- Roblox Support: https://en.help.roblox.com/hc/en-us/articles/115005744663-Troubleshooting-Education-Networks
- Roblox Support login/captcha: https://en.help.roblox.com/hc/en-us/articles/203312820-Issues-Logging-In-or-Out-in-a-Browser
- Gaijin Support ports: https://support.gaijin.net/hc/en-us/articles/200070211--War-Thunder-game-ports
- Gaijin Support auth error: https://support.gaijin.net/hc/en-us/articles/200070361-Error-80130182-The-authorization-server-is-unavailable
- zapret Roblox discussion: https://github.com/bol-van/zapret/discussions/1928
