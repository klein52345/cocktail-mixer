# HISTORY DOMAIN PACK — 2026-09-30
# Built from the conversation history visible in this session plus current official service-domain references.
# The pack intentionally contains both dedicated lists and a merged all-history list.

Services covered:
- Roblox / Roblox Studio
- War Thunder / Gaijin
- Enlisted
- Discord
- Telegram
- YouTube / Google video delivery
- GitHub / GitHub Content / GitHub API / GHCR
- Render / onrender.com / Render API
- Steam / Valve / Workshop
- Project Zomboid / modding / Workshop-adjacent sites
- OpenAI / ChatGPT / API
- Python / PyPI / development package hosts
- Other modding/game sites explicitly discussed (Mod.io, Nexus Mods, CurseForge, The Long Dark, MelonLoader)

Important:
- Hostlists cover DNS hostnames. They do not automatically cover game services that connect directly to IP addresses.
- Shared CDN/provider roots (AWS, CloudFront, Akamai, Google, etc.) can create broad collateral matching. They are included because the requested goal is maximum coverage, not minimum collateral.
- For game entry/matchmaking, ports and IP ranges may still be required in addition to domain lists.

Current official checks used for this pack:
- Render docs: render.com, onrender.com, api.render.com, renderdns.com
- GitHub Docs: github.com, api.github.com, raw.githubusercontent.com, objects.githubusercontent.com, github-cloud.githubusercontent.com, codeload.github.com, lfs.github.com, ghcr.io
- Steam Support: steampowered.com, steamcommunity.com, steamgames.com, steamusercontent.com, steamcontent.com, steamstatic.com, akamaihd.net
- Gaijin Support: War Thunder TCP/UDP and launcher ports
- Telegram API docs: core.telegram.org and Telegram API/Bot API infrastructure
- Roblox support/developer references: roblox.com, rbxcdn.com, assetgame.roblox.com and API/service endpoints
- Enlisted official site/forum references: enlisted.net, forum.enlisted.net and Gaijin account infrastructure
- OpenAI platform: api.openai.com / platform.openai.com
