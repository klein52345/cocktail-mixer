$ErrorActionPreference = 'Stop'
$packageRoot = Split-Path -Parent $PSScriptRoot
$sourceList = Join-Path $packageRoot 'lists\list-general-user.txt'
if (-not (Test-Path -LiteralPath $sourceList)) { throw "Не найден список: $sourceList" }

Write-Host 'AI hostlist installer для Flowseal zapret' -ForegroundColor Cyan
Write-Host 'Укажи папку Flowseal, в которой находятся service.bat и lists.'
$flowsealRoot = (Read-Host 'Папка Flowseal').Trim().Trim('"')
if (-not $flowsealRoot -or -not (Test-Path -LiteralPath $flowsealRoot -PathType Container)) {
    throw 'Папка не найдена. Ничего не изменено.'
}
$listsDir = Join-Path $flowsealRoot 'lists'
if (-not (Test-Path -LiteralPath $listsDir -PathType Container)) {
    throw 'В выбранной папке нет lists. Укажи корень Flowseal.'
}
$destination = Join-Path $listsDir 'list-general-user.txt'
$encoding = [System.Text.UTF8Encoding]::new($false)
$existingLines = @()
if (Test-Path -LiteralPath $destination) {
    $backup = "$destination.bak-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
    Copy-Item -LiteralPath $destination -Destination $backup
    $existingLines = [System.IO.File]::ReadAllLines($destination)
    Write-Host "Резервная копия: $backup" -ForegroundColor Green
}
$seen = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
foreach ($line in $existingLines) {
    $value = $line.Trim()
    if ($value -and -not $value.StartsWith('#')) { [void]$seen.Add($value) }
}
$added = [System.Collections.Generic.List[string]]::new()
foreach ($line in [System.IO.File]::ReadAllLines($sourceList)) {
    $value = $line.Trim()
    if (-not $value -or $value.StartsWith('#')) { continue }
    if ($seen.Add($value)) { $added.Add($value) }
}
$resultLines = [System.Collections.Generic.List[string]]::new()
foreach ($line in $existingLines) { $resultLines.Add($line) }
if ($resultLines.Count -gt 0 -and $resultLines[$resultLines.Count - 1] -ne '') { $resultLines.Add('') }
foreach ($line in $added) { $resultLines.Add($line) }
[System.IO.File]::WriteAllLines($destination, $resultLines.ToArray(), $encoding)
Write-Host "Готово. Добавлено доменов: $($added.Count)" -ForegroundColor Green
Write-Host "Файл: $destination"
Write-Host 'Перезапусти zapret через service.bat. Скрипт не менял стратегии и IPv6.'
