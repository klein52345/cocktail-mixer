$ErrorActionPreference = 'SilentlyContinue'
$targets = @(
    'chatgpt.com', 'api.openai.com', 'claude.ai', 'gemini.google.com',
    'aistudio.google.com', 'copilot.microsoft.com', 'perplexity.ai',
    'deepseek.com', 'mistral.ai', 'grok.com', 'huggingface.co', 'suno.com'
)
$results = foreach ($domain in $targets) {
    $resolved = $false
    $addresses = ''
    try {
        $dns = Resolve-DnsName -Name $domain -Type A -DnsOnly -ErrorAction Stop
        $ips = @($dns | Where-Object { $_.IPAddress } | Select-Object -ExpandProperty IPAddress -Unique)
        $addresses = $ips -join ', '
        $resolved = ($ips.Count -gt 0)
    } catch { $addresses = 'DNS lookup failed' }
    $https = $false
    if ($resolved) {
        try { $https = [bool](Test-NetConnection -ComputerName $domain -Port 443 -InformationLevel Quiet -WarningAction SilentlyContinue) } catch {}
    }
    [pscustomobject]@{ Domain = $domain; DNS = $resolved; IPv4 = $addresses; TCP443 = $https }
}
$results | Format-Table -AutoSize
$out = Join-Path ([Environment]::GetFolderPath('Desktop')) 'ai-endpoints-check.csv'
$results | Export-Csv -LiteralPath $out -NoTypeInformation -Encoding UTF8
Write-Host ''
Write-Host "Отчёт сохранён: $out"
Write-Host 'Успешный TCP/443 не гарантирует вход или доступность аккаунта.'
