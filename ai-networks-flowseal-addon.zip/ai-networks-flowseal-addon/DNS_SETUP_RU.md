# DNS для нейросетей: Comss.one и Xbox DNS

Проверено 12.10.2026.

## Comss.one DNS — основной вариант для проверки
- DoH: https://dns.comss.one/dns-query
- DoT / Android Private DNS: dns.comss.one
- Обычные IPv4 DNS: 83.220.169.155 и 212.109.195.93
- Официальная инструкция: https://www.comss.ru/page.php?id=15310
- Статус и адреса: https://www.comss.ru/page.php?id=7315

Android / Infinity-X: Настройки → Частный DNS → имя хоста dns.comss.one. Если HAPP/VLESS управляет DNS внутри туннеля, после изменения проверь обе конфигурации — системный Private DNS может конфликтовать с DNS-маршрутизацией VPN-клиента.

Chrome / Edge / Яндекс.Браузер / Firefox: включи безопасный DNS (DNS-over-HTTPS) и укажи https://dns.comss.one/dns-query, если браузер позволяет задать собственный DoH URL.

Обычные IPv4 DNS не шифруют DNS-запросы. DoH/DoT шифруют только запросы между устройством и резолвером, а не весь трафик сайтов. HTTPS к сайтам идёт напрямую, если отдельно не задействован VPN/прокси.

## Xbox DNS — временно не включай
Официальная страница https://xbox-dns.ru/ на момент проверки отображала уведомление «Сервис временно не работает». После восстановления можно перепроверить:
- DoH: https://xbox-dns.ru/dns-query
- DoT / Android Private DNS: xbox-dns.ru
- IPv4: 111.88.96.54 и 111.88.96.55
- IPv6: 2a00:ab00:1233:26::50 и 2a00:ab00:1233:26::51

Не смешивай DNS-адреса разных Smart DNS провайдеров в одной паре.

## Ограничения
Smart DNS может маршрутизировать только поддерживаемые им сервисы. Это не гарантирует работу любого приложения, API или аккаунта. При ограничениях аккаунта или дополнительных региональных проверках смена DNS может не помочь.

Источники:
- Comss: https://www.comss.ru/page.php?id=7315
- Список AI-сервисов Comss: https://www.comss.ru/page.php?id=13068
- Xbox DNS: https://xbox-dns.ru/
