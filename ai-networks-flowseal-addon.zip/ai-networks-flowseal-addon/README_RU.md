# AI Networks Add-on для zapret by Flowseal

Отдельный дополнительный комплект для ИИ-сервисов. Rust и Steam не включены. Исходный архив zapret не заменяется.

## Содержимое
- lists/list-general-user.txt — основной список доменов нейросетей для Flowseal.
- lists/list-general-user-ai-deps.txt — необязательные общие домены зависимостей. Добавлять только если ломаются вход, Cloudflare challenge, виджет поддержки или загрузка файлов.
- scripts/install-to-flowseal.ps1 — резервирует текущий список и добавляет отсутствующие домены без дублей.
- scripts/check-ai-endpoints.ps1 — базовая проверка DNS и TCP/443.
- DNS_SETUP_RU.md — инструкции по Comss.one и Xbox DNS.

## Установка
1. Распакуй архив в отдельную папку.
2. Запусти scripts/install-to-flowseal.ps1.
3. Укажи путь к корню Flowseal, где находятся service.bat и папка lists.
4. Скрипт сделает резервную копию lists/list-general-user.txt и добавит домены, не трогая остальные настройки.
5. Перезапусти zapret через service.bat.

Можно вручную дописать строки из lists/list-general-user.txt в установленный Flowseal в lists/list-general-user.txt. По документации Flowseal, поддомены домена учитываются автоматически.

## Важные ограничения
- Это hostlist для правил zapret, а не VPN, прокси или средство шифрования всего трафика.
- Сам список не отменяет географические ограничения; DNS со Smart DNS-маршрутизацией может помочь только для сервисов, которые этот провайдер поддерживает.
- IP-адреса AI-платформ динамические и часто разделяются между множеством сайтов/CDN. Фиксированный IPSET здесь не включён: доменный список практичнее и меньше устаревает.
- Даже при открывающемся сайте сервис может ограничивать вход или аккаунт по собственным правилам.

Официальная справка OpenAI по доменам: https://help.openai.com/en/articles/9247338-network-recommendations-for-chatgpt-errors-on-web-and-apps
Comss.one DNS: https://www.comss.ru/page.php?id=7315
